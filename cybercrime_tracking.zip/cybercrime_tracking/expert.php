<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cybertrack";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

session_start();

if (!isset($_SESSION['username']) || !isset($_SESSION['role'])) {
    echo "Access denied: Not logged in.";
    exit();
}

// Check if the user has the EXPERT role
if ($_SESSION['role'] !== 'EXPERT') {
    echo "Access denied: You do not have expert access.";
    exit();
}

$username = $_SESSION['username'];

// ✅ Get userID from users table
$stmt = $conn->prepare("SELECT userID FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $userID = $row['userID'];
} else {
    echo "Access denied: User record not found.";
    exit();
}
$stmt->close();

//Get ExpertID 
$stmt = $conn->prepare("SELECT ExpertID FROM expert WHERE userID = ?");
$stmt->bind_param("i", $userID);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $expertID = $row['ExpertID'];
} else {
    echo "Access denied: Expert record not found.";
    exit();
}
$stmt->close();

// ✅ Handle update expert details
if (isset($_POST['update_details'])) {
    $name = $_POST['name'];
    $designation = $_POST['designation'];
    $availability = $_POST['availability'];
    

    $stmt = $conn->prepare("UPDATE expert SET ExpertName=?, Designation=?, AvailabilityStatus=Upper(?) WHERE userID=?");
    $stmt->bind_param("sssi", $name, $designation, $availability,  $userID);
    $stmt->execute();
    $stmt->close();
}

// ✅ Handle case status update
if (isset($_POST['update_status'])) {
    $caseID = $_POST['case_id'];
    $status = $_POST['status'];

    $stmt = $conn->prepare("UPDATE cases SET status=? WHERE CaseID=? AND expertID=?");
    $stmt->bind_param("sii", $status, $caseID, $expertID);
    $stmt->execute();
    $stmt->close();
}

// ✅ Get list of criminals who are WANTED or UNKNOWN
$criminal_stmt = $conn->prepare("SELECT CriminalID, CriminalName FROM criminals WHERE Status IN ('WANTED', 'UNKNOWN')");
$criminal_stmt->execute();
$criminals_result = $criminal_stmt->get_result();
$criminals = [];
while ($row = $criminals_result->fetch_assoc()) {
    $criminals[] = $row;
}
$criminal_stmt->close();

if (isset($_POST['identify_criminal'])) {
    $caseID = $_POST['case_id'];
    $criminalID = $_POST['criminal_id'];

    // Optional: check if already linked to prevent duplicates
    $check_stmt = $conn->prepare("SELECT * FROM case_criminal WHERE CaseID = ? AND CriminalID = ?");
    $check_stmt->bind_param("ii", $caseID, $criminalID);
    $check_stmt->execute();
    $exists = $check_stmt->get_result()->num_rows > 0;
    $check_stmt->close();

    if (!$exists) {
        $insert_stmt = $conn->prepare("INSERT INTO case_criminal (CaseID, CriminalID) VALUES (?, ?)");
        $insert_stmt->bind_param("ii", $caseID, $criminalID);
        $insert_stmt->execute();
        $insert_stmt->close();
             }
}

// ✅ Fetch expert details
$stmt = $conn->prepare("SELECT * FROM expert WHERE userID = ?");
$stmt->bind_param("i", $userID);
$stmt->execute();
$expert_result = $stmt->get_result();
$expert_data = $expert_result->fetch_assoc();
$stmt->close();

$stmt = $conn->prepare("SELECT CriminalID FROM case_criminal WHERE CaseID = ?");
$stmt->bind_param("i", $case['CaseID']);
$stmt->execute();
$result = $stmt->get_result();
$identifiedCriminalID = null;

if ($row = $result->fetch_assoc()) {
    $identifiedCriminalID = $row['CriminalID'];
}
$stmt->close();

// ✅ Fetch assigned cases
$stmt = $conn->prepare("SELECT * FROM cases WHERE ExpertID = ?");
$stmt->bind_param("i", $expertID);
$stmt->execute();
$cases_result = $stmt->get_result();
$stmt->close();
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Expert Dashboard</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 0;
        }
        .nav {
            background-color: #2c3e50;
            padding: 15px;
            text-align: center;
        }
        .nav a {
            color: white;
            text-decoration: none;
            margin: 0 20px;
            font-weight: bold;
        }
        .nav a:hover {
            text-decoration: underline;
        }
        .container {
            width: 90%;
            margin: 40px auto;
            background: #fff;
            padding: 30px;
            box-shadow: 0 0 12px rgba(0, 0, 0, 0.1);
        }
        h1, h2 {
            text-align: center;
            color: #333;
        }
        label {
            display: block;
            margin: 10px 0 5px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 25px;
            margin-bottom: 40px;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }
        th {
            background-color: #2c3e50;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        form {
            max-width: 600px;
            margin: auto;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        input[type="text"], input[type="number"], select, button {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 15px;
        }
        button {
            background-color: #2c3e50;
            color: white;
            border: none;
            transition: background-color 0.3s ease;
            cursor: pointer;
        }
        button:hover {
            background-color: #1a252f;
        }
    </style>
</head>
<body>

<div class="nav">
    <a href="admin.php">Admin</a>
    <a href="victim.php">Victim</a>
    <a href="expert.php">Expert</a>
</div>

<div class="container">
    <h1>Expert Dashboard</h1>

    <h2>Your Details</h2>
    <?php if ($expert_data): ?>
    <form method="post">
        <input type="text" name="name" value="<?= htmlspecialchars($expert_data['ExpertName']) ?>" placeholder="Name" required>
        <input type="text" name="designation" value="<?= htmlspecialchars($expert_data['Designation']) ?>" placeholder="Designation" required>
        <input type="text" name="availability" value="<?= htmlspecialchars($expert_data['AvailabilityStatus']) ?>" placeholder="Availability Status(Busy, Available)" required>
        <?= htmlspecialchars($expert_data['caseCount']) ?>
        <button type="submit" name="update_details">Update Details</button>
    </form>
    <?php else: ?>
        <p style="text-align:center; color:red;">Expert details not found. Please contact admin.</p>
    <?php endif; ?>

    <h2>Assigned Cases</h2>
    <table>
        <tr>
            <th>Case ID</th>
            <th>Title</th>
            <th>Status</th>
            <th>Update Status</th>
            <th>Criminal Involved</th>
        </tr>
        <?php while ($case = $cases_result->fetch_assoc()): ?>
            <tr>
                <td><?= $case['caseID'] ?></td>
                <td><?= htmlspecialchars($case['Title']) ?></td>
                <td><?= htmlspecialchars($case['status']) ?></td>
                <td>
                    <form method="post" style="display:inline-block">
                        <input type="hidden" name="case_id" value="<?= $case['caseID'] ?>">
                        <select name="status">
                            <option value="PENDING" <?= $case['status'] == 'PENDING' ? 'selected' : '' ?>>PENDING</option>
                            <option value="ONGOING" <?= $case['status'] == 'ONGOING' ? 'selected' : '' ?>>ONGOING</option>
                            <option value="RESOLVED" <?= $case['status'] == 'RESOLVED' ? 'selected' : '' ?>>RESOLVED</option>
                        </select>
                        <button type="submit" name="update_status">Update</button>
                    </form>
                </td>
                <td>
                     <form method="post" style="display:inline-block;">
                        <input type="hidden" name="case_id" value="<?= $case['caseID'] ?>">
                    <select name="criminal_id" required>
                        <option value="">--Select Criminal--</option>
                        <?php foreach ($criminals as $criminal): ?>
                        <option value="<?= $criminal['CriminalID'] ?>">
                        <?= ($criminal['CriminalID'] == $identifiedCriminalID) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($criminal['CriminalName']) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" name="identify_criminal">Assign Criminal</button>
                </form>
                </td>
            </tr>
        <?php endwhile; ?>
        <?php if ($cases_result->num_rows === 0): ?>
            <tr><td colspan="4">No cases assigned.</td></tr>
        <?php endif; ?>
    </table>
</div>

</body>
</html>
