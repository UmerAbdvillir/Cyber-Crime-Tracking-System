-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 27, 2025 at 09:15 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cybertrack`
--

-- --------------------------------------------------------

--
-- Table structure for table `cases`
--

CREATE TABLE `cases` (
  `CaseID` int(11) NOT NULL,
  `Title` varchar(50) NOT NULL,
  `caseStatus` char(20) DEFAULT NULL CHECK (`caseStatus` in ('PENDING','IN PROGRESS','RESOLVED')),
  `VictimID` int(11) DEFAULT NULL,
  `ExpertID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `case_criminal`
--

CREATE TABLE `case_criminal` (
  `CaseID` int(11) NOT NULL,
  `CriminalID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `criminals`
--

CREATE TABLE `criminals` (
  `CriminalID` int(11) NOT NULL,
  `CriminalName` char(50) NOT NULL,
  `PreviousRecord` varchar(30) DEFAULT NULL,
  `Status` char(15) DEFAULT NULL CHECK (`Status` in ('CAUGHT','WANTED','UNKNOWN'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `expert`
--

CREATE TABLE `expert` (
  `ExpertID` int(11) NOT NULL,
  `ExpertName` char(30) NOT NULL,
  `userID` int(11) DEFAULT NULL,
  `Designation` char(30) DEFAULT NULL,
  `caseCount` int(11) DEFAULT NULL,
  `AvailabilityStatus` char(10) DEFAULT NULL CHECK (`AvailabilityStatus` in ('AVAILABLE','BUSY'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userID` int(11) NOT NULL,
  `userName` char(30) NOT NULL,
  `pass` char(10) DEFAULT NULL CHECK (char_length(`pass`) >= 6 and char_length(`pass`) < 15),
  `Role` char(20) DEFAULT 'VICTIM' CHECK (`Role` in ('ADMIN','VICTIM','EXPERT'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `userName`, `pass`, `Role`) VALUES
(1, 'Carlos', 'carlos', 'ADMIN'),
(2, 'Professor', 'professor', 'VICTIM');

-- --------------------------------------------------------

--
-- Table structure for table `victim`
--

CREATE TABLE `victim` (
  `VictimID` int(11) NOT NULL,
  `VictimName` char(50) NOT NULL,
  `userID` int(11) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `phone` char(13) DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cases`
--
ALTER TABLE `cases`
  ADD PRIMARY KEY (`CaseID`),
  ADD KEY `VictimID` (`VictimID`),
  ADD KEY `ExpertID` (`ExpertID`);

--
-- Indexes for table `case_criminal`
--
ALTER TABLE `case_criminal`
  ADD PRIMARY KEY (`CaseID`,`CriminalID`),
  ADD KEY `CriminalID` (`CriminalID`);

--
-- Indexes for table `criminals`
--
ALTER TABLE `criminals`
  ADD PRIMARY KEY (`CriminalID`);

--
-- Indexes for table `expert`
--
ALTER TABLE `expert`
  ADD PRIMARY KEY (`ExpertID`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `userName` (`userName`);

--
-- Indexes for table `victim`
--
ALTER TABLE `victim`
  ADD PRIMARY KEY (`VictimID`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD KEY `userID` (`userID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cases`
--
ALTER TABLE `cases`
  MODIFY `CaseID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=701;

--
-- AUTO_INCREMENT for table `criminals`
--
ALTER TABLE `criminals`
  MODIFY `CriminalID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=501;

--
-- AUTO_INCREMENT for table `expert`
--
ALTER TABLE `expert`
  MODIFY `ExpertID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=301;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `victim`
--
ALTER TABLE `victim`
  MODIFY `VictimID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cases`
--
ALTER TABLE `cases`
  ADD CONSTRAINT `cases_ibfk_1` FOREIGN KEY (`VictimID`) REFERENCES `victim` (`VictimID`),
  ADD CONSTRAINT `cases_ibfk_2` FOREIGN KEY (`ExpertID`) REFERENCES `expert` (`ExpertID`);

--
-- Constraints for table `case_criminal`
--
ALTER TABLE `case_criminal`
  ADD CONSTRAINT `case_criminal_ibfk_1` FOREIGN KEY (`CaseID`) REFERENCES `cases` (`CaseID`),
  ADD CONSTRAINT `case_criminal_ibfk_2` FOREIGN KEY (`CriminalID`) REFERENCES `criminals` (`CriminalID`);

--
-- Constraints for table `expert`
--
ALTER TABLE `expert`
  ADD CONSTRAINT `expert_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`);

--
-- Constraints for table `victim`
--
ALTER TABLE `victim`
  ADD CONSTRAINT `victim_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
