<?php
$userInput = $_POST["username"];
$passInput = $_POST["password"];

$host = "localhost";
$dbname = "cybertrack";
$username = "root";
$password = "";

$conn = mysqli_connect($host, $username, $password, $dbname);

if (mysqli_connect_errno()) {
    die("Connection Error: " . mysqli_connect_error());
}

// Step 1: Check if user exists with correct password
$sql_check = "SELECT * FROM users WHERE userName = ? AND pass = ?";
$stmt_check = mysqli_prepare($conn, $sql_check);
mysqli_stmt_bind_param($stmt_check, "ss", $userInput, $passInput);
mysqli_stmt_execute($stmt_check);
$result = mysqli_stmt_get_result($stmt_check);

if ($row = mysqli_fetch_assoc($result)) {
    $role = $row['Role'];

    session_start();
    $_SESSION['username'] = $userInput;
    $_SESSION['role'] = $role;
    $_SESSION['user_id'] = $row['userID'];  



    if ($role === 'ADMIN') {
        header("Location: admin.php");
        exit();
    } elseif ($role === 'VICTIM') {
        header("Location: victim.php");
        exit();
    } elseif ($role === 'EXPERT') {
        header("Location: expert.php");
        exit();
    } else {
        echo "Unknown role.";
        exit();
    }
}
 else {
    // Step 2: Check if username already exists (wrong password case)
    $sql_user_exists = "SELECT * FROM users WHERE userName = ?";
    $stmt_user_exists = mysqli_prepare($conn, $sql_user_exists);
    mysqli_stmt_bind_param($stmt_user_exists, "s", $userInput);
    mysqli_stmt_execute($stmt_user_exists);
    $user_exists_result = mysqli_stmt_get_result($stmt_user_exists);

    if (mysqli_fetch_assoc($user_exists_result)) {
        // User exists but password is incorrect
        echo "Incorrect password.";
        exit();
    }

    // Step 3: Register new user as VICTIM by default
    $default_role = "VICTIM";
    $sql_insert = "INSERT INTO users (userName, pass, Role) VALUES (?, ?, ?)";
    $stmt_insert = mysqli_prepare($conn, $sql_insert);

    if (!$stmt_insert) {
        die("SQL error: " . mysqli_error($conn));
    }

    mysqli_stmt_bind_param($stmt_insert, "sss", $userInput, $passInput, $default_role);
    mysqli_stmt_execute($stmt_insert);

    $userID = mysqli_insert_id($conn);
      
    $stmtVictim = $conn->prepare("INSERT INTO Victim (UserID, VictimName, Email, phone, Address) VALUES (?, ?, NULL, NULL, NULL)");
    $stmtVictim->bind_param("is", $userID, $userInput);
    $stmtVictim->execute();
    $stmtVictim->close();

     session_start();
    $_SESSION['username'] = $userInput;
    $_SESSION['role'] = $default_role;
    $_SESSION['user_id'] = $userID;  
    header("Location: victim.php");
    exit();
}
?>
