<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cybertrack";

session_start();

if (!isset($_SESSION['username']) || !isset($_SESSION['role'])) {
    echo "Access denied: Not logged in.";
    exit();
}

if ($_SESSION['role'] !== 'ADMIN') {
    echo "Access denied: You do not have admin access.";
    exit();
}

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// --- Handle Role Change ---
if (isset($_POST['change_role'])) {
    $userID = $_POST['user_id'];
    $newRole = $_POST['new_role'];

    // Begin transaction
    $conn->begin_transaction();

    try {
        // Fetch current role
        $result = $conn->query("SELECT Role, userName FROM users WHERE userID = $userID");
        $row = $result->fetch_assoc();
        $currentRole = $row['Role'];
        $userName = $row['userName'];

        // Disallow role change to/from ADMIN
        if ($currentRole === 'ADMIN' || $newRole === 'ADMIN') {
            throw new Exception("Invalid operation: Cannot change role to/from ADMIN.");
        }

        // Update role in users table
        $conn->query("UPDATE users SET Role = '$newRole' WHERE userID = $userID");

        if ($currentRole === 'EXPERT' && $newRole === 'VICTIM') {
            // Remove expert details on demotion
            $conn->query("DELETE FROM expert WHERE userID = $userID");
        }

        if ($currentRole === 'VICTIM' && $newRole === 'EXPERT') {
            // Insert expert details on promotion
            $stmt = $conn->prepare("INSERT INTO expert (userID, ExpertName, AvailabilityStatus, caseCount) VALUES (?, ?, NULL, 0)");
            $stmt->bind_param("is", $userID, $userName);
            $stmt->execute();
        }

        // Commit if all succeeded
        $conn->commit();
    } catch (Exception $e) {
        $conn->rollback();
        die("Role change failed: " . $e->getMessage());
    }
}

// --- Handle Expert Assignment ---
if (isset($_POST['assign_expert'])) {
    $caseID = $_POST['case_id'];
    $expertID = $_POST['expert_id'];

    // Start transaction
    $conn->begin_transaction();

    try {
        // 1. Assign the expert to the case
        $stmt1 = $conn->prepare("UPDATE cases SET ExpertID = ? WHERE CaseID = ?");
        $stmt1->bind_param("ii", $expertID, $caseID);
        $stmt1->execute();

        // 2. Update availability to BUSY
        $stmt2 = $conn->prepare("UPDATE expert SET AvailabilityStatus = 'BUSY' WHERE ExpertID = ?");
        $stmt2->bind_param("i", $expertID);
        $stmt2->execute();

        // 3. Increment the expert's caseCount
        $stmt3 = $conn->prepare("UPDATE expert SET caseCount = caseCount + 1 WHERE ExpertID = ?");
        $stmt3->bind_param("i", $expertID);
        $stmt3->execute();

        // If all succeed, commit
        $conn->commit();
        echo "Expert assigned successfully!";
    } catch (Exception $e) {
        // If any fail, rollback
        $conn->rollback();
        echo "Failed to assign expert: " . $e->getMessage();
    }
}


// --- Fetch all users (excluding admins for role changing) ---
$users_result = $conn->query("SELECT * FROM users WHERE Role != 'ADMIN'");

// --- Fetch all cases with joined data ---
$cases_result = $conn->query("
    SELECT c.CaseID, c.Title, c.status, c.date_reported,
           v.VictimName, e.ExpertName
    FROM cases c
    LEFT JOIN victim v ON c.VictimID = v.VictimID
    LEFT JOIN expert e ON c.ExpertID = e.ExpertID
");

// --- Available experts for assignment ---
$available_experts = $conn->query("
    SELECT e.ExpertID, e.ExpertName 
    FROM expert e 
    WHERE e.AvailabilityStatus = 'AVAILABLE'
");

// --- Open cases for assignment ---
$open_cases = $conn->query("SELECT CaseID, Title FROM cases WHERE ExpertID IS NULL");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background-color: #f4f6f9; margin: 0; padding: 0; }
        .nav { background-color: #343a40; padding: 15px; text-align: center; }
        .nav a { color: white; text-decoration: none; margin: 0 20px; font-weight: bold; }
        .container { width: 95%; margin: 40px auto; background: #fff; padding: 30px; box-shadow: 0 0 12px rgba(0,0,0,0.1); }
        h1, h2 { text-align: center; color: #333; }
        table { width: 100%; border-collapse: collapse; margin-top: 25px; margin-bottom: 40px; }
        th, td { padding: 12px; border: 1px solid #ddd; text-align: center; }
        th { background-color: #343a40; color: white; }
        tr:nth-child(even) { background-color: #f2f2f2; }
        form { max-width: 600px; margin: 20px auto; display: flex; flex-direction: column; gap: 10px; }
        input, select, button { padding: 10px; border: 1px solid #ccc; border-radius: 4px; font-size: 15px; }
        button { background-color: #343a40; color: white; cursor: pointer; }
        button:hover { background-color: #23272b; }
    </style>
</head>
<body>

<div class="nav">
    <a href="admin.php">Admin</a>
    <a href="victim.php">Victim</a>
    <a href="expert.php">Expert</a>
</div>

<div class="container">
    <h1>Admin Dashboard</h1>

    <!-- CASE LISTING -->
    <h2>All Cases</h2>
    <table>
        <tr>
            <th>Case ID</th>
            <th>Title</th>
            <th>Victim</th>
            <th>Expert</th>
            <th>Status</th>
            <th>Date Created</th>
        </tr>
        <?php while ($row = $cases_result->fetch_assoc()) {
            echo "<tr>
                    <td>{$row['CaseID']}</td>
                    <td>{$row['Title']}</td>
                    <td>{$row['VictimName']}</td>
                    <td>{$row['ExpertName']}</td>
                    <td>{$row['status']}</td>
                    <td>{$row['date_reported']}</td>
                </tr>";
        } ?>
    </table>

    <!-- ASSIGN EXPERT -->
    <h2>Assign Expert to Case</h2>
    <form method="post">
        <select name="case_id" required>
            <option value="">Select a Case</option>
            <?php while ($c = $open_cases->fetch_assoc()) {
                echo "<option value='{$c['CaseID']}'>{$c['Title']} (ID: {$c['CaseID']})</option>";
            } ?>
        </select>
        <select name="expert_id" required>
            <option value="">Select Available Expert</option>
            <?php while ($e = $available_experts->fetch_assoc()) {
                echo "<option value='{$e['ExpertID']}'>{$e['ExpertName']} (ID: {$e['ExpertID']})</option>";
            } ?>
        </select>
        <button type="submit" name="assign_expert">Assign</button>
    </form>

    <!-- CHANGE USER ROLE -->
    <h2>Change User Role</h2>
    <form method="post">
        <select name="user_id" required>
            <option value="">Select User</option>
            <?php
            $users_result->data_seek(0);
            while ($u = $users_result->fetch_assoc()) {
                echo "<option value='{$u['userID']}'>{$u['userName']} (Current: {$u['Role']})</option>";
            }
            ?>
        </select>
        <select name="new_role" required>
            <option value="">Select New Role</option>
            <option value="EXPERT">EXPERT</option>
            <option value="VICTIM">VICTIM</option>
        </select>
        <button type="submit" name="change_role">Update Role</button>
    </form>
</div>

</body>
</html>
