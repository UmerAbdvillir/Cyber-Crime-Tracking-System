<?php


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cybertrack";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

session_start();

if (!isset($_SESSION['username']) || !isset($_SESSION['role'])) {
    echo "Access denied: Not logged in.";
    exit();
}

if ($_SESSION['role'] !== 'VICTIM') {
    echo "Access denied: You do not have victim access.";
    exit();
}

$userID = $_SESSION['user_id'];
$victimID = null;

$victimQuery = $conn->prepare("SELECT VictimID FROM Victim WHERE UserID = ?");
$victimQuery->bind_param("i", $userID);
$victimQuery->execute();
$victimResult = $victimQuery->get_result();
if ($row = $victimResult->fetch_assoc()) {
    $victimID = $row['VictimID'];
} else {
    die("No victim account found for this user.");
}
$victimQuery->close();

$successMessage = "";
$errorMessage = "";

// Handle update
if (isset($_POST['update_details'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];

    $stmt = $conn->prepare("UPDATE victim SET VictimName=?, Email=?, Phone=?, Address=? WHERE userID=?");
    $stmt->bind_param("ssssi", $name, $email, $phone, $address, $userID);
    if ($stmt->execute()) {
        $successMessage = "Details updated successfully.";
    } else {
        $errorMessage = "Failed to update details.";
    }
    $stmt->close();
}

// Handle case submission
if (isset($_POST['submit_case'])) {
    $title = trim($_POST['title']);
    $incidentDate = $_POST['date_reported'];
    $description = trim($_POST['description']);
    $type = trim($_POST['type']);
    $criminalName = trim($_POST['criminal']);

    if (!empty($title) && !empty($incidentDate) && !empty($description) && !empty($type)) {
        $stmt = $conn->prepare("INSERT INTO Cases (Title, status, VictimID, date_reported, Description, Type) VALUES (?, 'PENDING', ?, ?, ?, ?)");
        $stmt->bind_param("sisss", $title, $victimID, $incidentDate, $description, $type);
        if ($stmt->execute()) {
            $caseID = $stmt->insert_id;

            if (!empty($criminalName)) {
                $checkCriminal = $conn->prepare("SELECT CriminalID FROM Criminals WHERE CriminalName = ?");
                $checkCriminal->bind_param("s", $criminalName);
                $checkCriminal->execute();
                $result = $checkCriminal->get_result();
                if ($result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    $criminalID = $row['CriminalID'];

                    $link = $conn->prepare("INSERT INTO Case_Criminal (CaseID, CriminalID) VALUES (?, ?)");
                    $link->bind_param("ii", $caseID, $criminalID);
                    $link->execute();
                }
            }
            $successMessage = "Case submitted successfully.";
        } else {
            $errorMessage = "Case submission failed: " . $conn->error;
        }
        $stmt->close();
    } else {
        $errorMessage = "Please fill in all required fields.";
    }
}

// Fetch victim info
$victim_sql = "SELECT * FROM Victim WHERE VictimID = ?";
$stmtVictim = $conn->prepare($victim_sql);
$stmtVictim->bind_param("i", $victimID);
$stmtVictim->execute();
$victimResult = $stmtVictim->get_result();
$victim = $victimResult->fetch_assoc();
$stmtVictim->close();

// Fetch case records
$case_sql = "
    SELECT c.CaseID, c.Title, c.status, c.date_reported, c.Description, c.Type,
           e.ExpertName,
           GROUP_CONCAT(cr.CriminalName SEPARATOR ', ') AS Criminals
    FROM Cases c
    LEFT JOIN Expert e ON c.ExpertID = e.ExpertID
    LEFT JOIN Case_Criminal cc ON c.CaseID = cc.CaseID
    LEFT JOIN Criminals cr ON cc.CriminalID = cr.CriminalID
    WHERE c.VictimID = ?
    GROUP BY c.CaseID
";
$stmtCases = $conn->prepare($case_sql);
$stmtCases->bind_param("i", $victimID);
$stmtCases->execute();
$caseResult = $stmtCases->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Victim Dashboard</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background-color: #f0f2f5; margin: 0; padding: 0; }
        .nav { background-color: #2c3e50; padding: 15px; text-align: center; }
        .nav a { color: white; text-decoration: none; margin: 0 20px; font-weight: bold; }
        .container { width: 90%; margin: 40px auto; background: #fff; padding: 30px; box-shadow: 0 0 12px rgba(0, 0, 0, 0.1); }
        h1, h2 { text-align: center; color: #333; }
        table { width: 100%; border-collapse: collapse; margin-top: 25px; margin-bottom: 40px; }
        th, td { padding: 12px; border: 1px solid #ddd; text-align: center; }
        th { background-color: #2c3e50; color: white; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        form { max-width: 600px; margin: auto; display: flex; flex-direction: column; gap: 12px; }
        input[type="text"], input[type="date"], textarea, select, button {
            padding: 10px; border: 1px solid #ccc; border-radius: 4px; font-size: 15px;
        }
        textarea { resize: vertical; }
        button { background-color: #2c3e50; color: white; border: none; transition: background-color 0.3s ease; cursor: pointer; }
        button:hover { background-color: #1a252f; }
        .message { text-align: center; font-weight: bold; margin: 20px 0; }
        .success { color: green; }
        .error { color: red; }
    </style>
</head>
<body>
<div class="nav">
    <a href="admin.php">Admin</a>
    <a href="victim.php">Victim</a>
    <a href="expert.php">Expert</a>
</div>

<div class="container">
    <h1>Victim Dashboard</h1>

    <h2>Victim Information</h2>
    <?php if ($victim): ?>
    <form method="post">
        <input type="text" name="name" value="<?= htmlspecialchars($victim['VictimName']) ?>" placeholder="Name" required>
        <input type="text" name="email" value="<?= htmlspecialchars($victim['Email']) ?>" placeholder="Email" required>
        <input type="text" name="phone" value="<?= htmlspecialchars($victim['phone']) ?>" placeholder="Phone" required>
        <input type="text" name="address" value="<?= htmlspecialchars($victim['Address']) ?>" placeholder="Address" required>
        <button type="submit" name="update_details">Update Details</button>
    </form>
    <?php else: ?>
        <p>No victim data found.</p>
    <?php endif; ?>

    <h2>Case Records</h2>
    <table>
        <tr>
            <th>Case ID</th>
            <th>Title</th>
            <th>Type</th>
            <th>Date</th>
            <th>Status</th>
            <th>Expert</th>
            <th>Criminal(s)</th>
        </tr>
        <?php if ($caseResult && $caseResult->num_rows > 0): ?>
            <?php while ($row = $caseResult->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['CaseID'] ?></td>
                    <td><?= htmlspecialchars($row['Title']) ?></td>
                    <td><?= htmlspecialchars($row['Type']) ?></td>
                    <td><?= htmlspecialchars($row['date_reported']) ?></td>
                    <td><?= htmlspecialchars($row['status']) ?></td>
                    <td><?= htmlspecialchars($row['ExpertName'] ?? 'Unassigned') ?></td>
                    <td><?= htmlspecialchars($row['Criminals'] ?? 'None') ?></td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="7">No cases reported yet.</td></tr>
        <?php endif; ?>
    </table>

    <h2>Report a New Case</h2>
    <?php if ($successMessage): ?>
        <div class="message success"><?= $successMessage ?></div>
    <?php endif; ?>
    <?php if ($errorMessage): ?>
        <div class="message error"><?= $errorMessage ?></div>
    <?php endif; ?>
    <form method="post" action="">
        <input type="text" name="title" placeholder="Enter Case Title" required>
        <input type="date" name="date_reported" required>
        <textarea name="description" placeholder="Describe the incident" rows="4" required></textarea>
        <select name="type" required>
            <option value="">-- Select Case Type --</option>
            <option value="Fraud">Fraud</option>
            <option value="Harassment">Harassment</option>
            <option value="Phishing">Phishing</option>
            <option value="Malware">Malware</option>
        </select>
        <input type="text" name="criminal" placeholder="Suspected Criminal Name (optional)">
        <button type="submit" name="submit_case">Submit Case</button>
    </form>
</div>
</body>
</html>
